

docker build -f services/order_management/deployment/Dockerfile -t order-management-service .